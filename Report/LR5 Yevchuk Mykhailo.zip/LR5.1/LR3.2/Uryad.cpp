#include "Uryad.h"

Uryad::Uryad(string t) : type(t) {}

string Uryad::getType() const {
    return type;
}