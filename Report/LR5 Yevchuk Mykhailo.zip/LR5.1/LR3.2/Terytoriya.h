﻿#pragma once
#include <string>
using namespace std;
class Terytoriya {
    int ploshcha; 
public:
    Terytoriya(int p = 0);
    string getInfo() const;
};