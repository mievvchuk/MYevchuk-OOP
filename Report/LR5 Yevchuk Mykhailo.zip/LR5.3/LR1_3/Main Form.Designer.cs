﻿namespace LR1_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.створитиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.зберегтиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вивестиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пошукToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.операториToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.обєднатиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.перевіритиРівністьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.агрегаціїToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.додатиПодорожДоАгенціїToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.показатиВсіАгенціїToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.порахуватиЗагальнийДохідАгенціїToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.композиціїToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.додатиЖитлоДоПоточноїПодорожіToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.показатиЖитлоПоточноїПодорожіToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.порахуватиПовнуВартістьЖитлаПодорожіToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(33, 36);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(755, 230);
            this.dataGridView1.TabIndex = 5;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.створитиToolStripMenuItem,
            this.зберегтиToolStripMenuItem,
            this.вивестиToolStripMenuItem,
            this.пошукToolStripMenuItem,
            this.операториToolStripMenuItem,
            this.агрегаціїToolStripMenuItem,
            this.композиціїToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // створитиToolStripMenuItem
            // 
            this.створитиToolStripMenuItem.Name = "створитиToolStripMenuItem";
            this.створитиToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.створитиToolStripMenuItem.Text = "Створити";
            this.створитиToolStripMenuItem.Click += new System.EventHandler(this.створитиToolStripMenuItem_Click);
            // 
            // зберегтиToolStripMenuItem
            // 
            this.зберегтиToolStripMenuItem.Name = "зберегтиToolStripMenuItem";
            this.зберегтиToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.зберегтиToolStripMenuItem.Text = "Зберегти";
            this.зберегтиToolStripMenuItem.Click += new System.EventHandler(this.зберегтиToolStripMenuItem_Click);
            // 
            // вивестиToolStripMenuItem
            // 
            this.вивестиToolStripMenuItem.Name = "вивестиToolStripMenuItem";
            this.вивестиToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.вивестиToolStripMenuItem.Text = "Вивести";
            this.вивестиToolStripMenuItem.Click += new System.EventHandler(this.вивестиToolStripMenuItem_Click_1);
            // 
            // пошукToolStripMenuItem
            // 
            this.пошукToolStripMenuItem.Name = "пошукToolStripMenuItem";
            this.пошукToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.пошукToolStripMenuItem.Text = "Пошук";
            this.пошукToolStripMenuItem.Click += new System.EventHandler(this.пошукToolStripMenuItem_Click);
            // 
            // операториToolStripMenuItem
            // 
            this.операториToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.обєднатиToolStripMenuItem,
            this.toolStripMenuItem4,
            this.перевіритиРівністьToolStripMenuItem});
            this.операториToolStripMenuItem.Name = "операториToolStripMenuItem";
            this.операториToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.операториToolStripMenuItem.Text = "Оператори";
            this.операториToolStripMenuItem.Click += new System.EventHandler(this.операториToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem2.Text = "++";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem3.Text = "--";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // обєднатиToolStripMenuItem
            // 
            this.обєднатиToolStripMenuItem.Name = "обєднатиToolStripMenuItem";
            this.обєднатиToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.обєднатиToolStripMenuItem.Text = "об\'єднати";
            this.обєднатиToolStripMenuItem.Click += new System.EventHandler(this.обєднатиToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem4.Text = "==";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // перевіритиРівністьToolStripMenuItem
            // 
            this.перевіритиРівністьToolStripMenuItem.Name = "перевіритиРівністьToolStripMenuItem";
            this.перевіритиРівністьToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.перевіритиРівністьToolStripMenuItem.Text = "перевірити рівність";
            this.перевіритиРівністьToolStripMenuItem.Click += new System.EventHandler(this.перевіритиРівністьToolStripMenuItem_Click);
            // 
            // агрегаціїToolStripMenuItem
            // 
            this.агрегаціїToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.додатиПодорожДоАгенціїToolStripMenuItem,
            this.показатиВсіАгенціїToolStripMenuItem,
            this.порахуватиЗагальнийДохідАгенціїToolStripMenuItem});
            this.агрегаціїToolStripMenuItem.Name = "агрегаціїToolStripMenuItem";
            this.агрегаціїToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.агрегаціїToolStripMenuItem.Text = "Агрегації";
            // 
            // додатиПодорожДоАгенціїToolStripMenuItem
            // 
            this.додатиПодорожДоАгенціїToolStripMenuItem.Name = "додатиПодорожДоАгенціїToolStripMenuItem";
            this.додатиПодорожДоАгенціїToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.додатиПодорожДоАгенціїToolStripMenuItem.Text = "Додати подорож до агенції";
            this.додатиПодорожДоАгенціїToolStripMenuItem.Click += new System.EventHandler(this.додатиПодорожДоАгенціїToolStripMenuItem_Click);
            // 
            // показатиВсіАгенціїToolStripMenuItem
            // 
            this.показатиВсіАгенціїToolStripMenuItem.Name = "показатиВсіАгенціїToolStripMenuItem";
            this.показатиВсіАгенціїToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.показатиВсіАгенціїToolStripMenuItem.Text = "Показати всі подорожі агенції";
            this.показатиВсіАгенціїToolStripMenuItem.Click += new System.EventHandler(this.показатиВсіАгенціїToolStripMenuItem_Click);
            // 
            // порахуватиЗагальнийДохідАгенціїToolStripMenuItem
            // 
            this.порахуватиЗагальнийДохідАгенціїToolStripMenuItem.Name = "порахуватиЗагальнийДохідАгенціїToolStripMenuItem";
            this.порахуватиЗагальнийДохідАгенціїToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.порахуватиЗагальнийДохідАгенціїToolStripMenuItem.Text = "Порахувати загальний дохід агенції";
            this.порахуватиЗагальнийДохідАгенціїToolStripMenuItem.Click += new System.EventHandler(this.порахуватиЗагальнийДохідАгенціїToolStripMenuItem_Click);
            // 
            // композиціїToolStripMenuItem
            // 
            this.композиціїToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.додатиЖитлоДоПоточноїПодорожіToolStripMenuItem,
            this.показатиЖитлоПоточноїПодорожіToolStripMenuItem,
            this.порахуватиПовнуВартістьЖитлаПодорожіToolStripMenuItem});
            this.композиціїToolStripMenuItem.Name = "композиціїToolStripMenuItem";
            this.композиціїToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.композиціїToolStripMenuItem.Text = "Композиції";
            // 
            // додатиЖитлоДоПоточноїПодорожіToolStripMenuItem
            // 
            this.додатиЖитлоДоПоточноїПодорожіToolStripMenuItem.Name = "додатиЖитлоДоПоточноїПодорожіToolStripMenuItem";
            this.додатиЖитлоДоПоточноїПодорожіToolStripMenuItem.Size = new System.Drawing.Size(277, 22);
            this.додатиЖитлоДоПоточноїПодорожіToolStripMenuItem.Text = "Додати житло до поточної подорожі";
            this.додатиЖитлоДоПоточноїПодорожіToolStripMenuItem.Click += new System.EventHandler(this.додатиЖитлоДоПоточноїПодорожіToolStripMenuItem_Click);
            // 
            // показатиЖитлоПоточноїПодорожіToolStripMenuItem
            // 
            this.показатиЖитлоПоточноїПодорожіToolStripMenuItem.Name = "показатиЖитлоПоточноїПодорожіToolStripMenuItem";
            this.показатиЖитлоПоточноїПодорожіToolStripMenuItem.Size = new System.Drawing.Size(277, 22);
            this.показатиЖитлоПоточноїПодорожіToolStripMenuItem.Text = "Показати житло поточної подорожі";
            this.показатиЖитлоПоточноїПодорожіToolStripMenuItem.Click += new System.EventHandler(this.показатиЖитлоПоточноїПодорожіToolStripMenuItem_Click);
            // 
            // порахуватиПовнуВартістьЖитлаПодорожіToolStripMenuItem
            // 
            this.порахуватиПовнуВартістьЖитлаПодорожіToolStripMenuItem.Name = "порахуватиПовнуВартістьЖитлаПодорожіToolStripMenuItem";
            this.порахуватиПовнуВартістьЖитлаПодорожіToolStripMenuItem.Size = new System.Drawing.Size(277, 22);
            this.порахуватиПовнуВартістьЖитлаПодорожіToolStripMenuItem.Text = "Порахувати повну вартість подорожі";
            this.порахуватиПовнуВартістьЖитлаПодорожіToolStripMenuItem.Click += new System.EventHandler(this.порахуватиПовнуВартістьЖитлаПодорожіToolStripMenuItem_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(143, 286);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(645, 150);
            this.dataGridView2.TabIndex = 7;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(33, 293);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 38);
            this.button2.TabIndex = 12;
            this.button2.Text = "Змінити тип подорожі";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.buttonChangeType_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Подорожуємо Україною";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem створитиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem зберегтиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вивестиToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ToolStripMenuItem пошукToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem операториToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem обєднатиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem перевіритиРівністьToolStripMenuItem;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem агрегаціїToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem додатиПодорожДоАгенціїToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem показатиВсіАгенціїToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem порахуватиЗагальнийДохідАгенціїToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem композиціїToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem додатиЖитлоДоПоточноїПодорожіToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem показатиЖитлоПоточноїПодорожіToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem порахуватиПовнуВартістьЖитлаПодорожіToolStripMenuItem;
    }
}

