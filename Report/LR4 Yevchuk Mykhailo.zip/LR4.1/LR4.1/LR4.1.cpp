﻿#include <iostream>
#include "D3.h"
using namespace std;
int main() {
    setlocale(0, "ukr");
    D3 d3;
    d3.input();
    d3.show();
    return 0;
}