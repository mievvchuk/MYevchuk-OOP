#pragma once
#include "D2.h"

class D3 : public D2 {
protected:
    string nameD3;
public:
    D3();
    ~D3();
    void input();
    void show();
};
