#pragma once
#include <iostream>
#include <string>
using namespace std;

class B1 {
protected:
    string nameB1;
    B1();
    ~B1();
public:
    void input();
    void show();
};
