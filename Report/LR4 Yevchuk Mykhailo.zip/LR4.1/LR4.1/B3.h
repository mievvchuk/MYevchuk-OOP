#pragma once
#include <iostream>
#include <string>
using namespace std;

class B3 {
protected:
    string nameB3;
    B3();
    ~B3();
public:
    void input();
    void show();
};
