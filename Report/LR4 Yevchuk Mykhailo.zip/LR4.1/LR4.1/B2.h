#pragma once
#include <iostream>
#include <string>
using namespace std;

class B2 {
protected:
    string nameB2;
public:
    B2();
    ~B2();
    void input();
    void show();
};
